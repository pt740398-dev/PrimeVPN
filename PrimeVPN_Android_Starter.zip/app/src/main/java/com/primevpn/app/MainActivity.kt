package com.primevpn.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF080B18)
private val Surface = Color(0xFF12182B)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF55D6E8)
private val Muted = Color(0xFF929BB5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeVpnApp() }
    }
}

@Composable
fun PrimeVpnApp() {
    var selectedServer by remember { mutableStateOf("Singapore") }
    var showServers by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Background,
            surface = Surface,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF11162B), Background, Color(0xFF090D1B))))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Purple.copy(alpha = .18f), RoundedCornerShape(12.dp))
                            .border(1.dp, Purple.copy(alpha = .5f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("P", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("PRIME VPN", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("PRIVATE • FAST • SECURE", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { showInfo = true }) {
                        Icon(Icons.Default.Info, contentDescription = "Information", tint = Muted)
                    }
                }

                Spacer(Modifier.height(42.dp))
                Text("YOUR CONNECTION", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(9.dp))
                Text("Not connected", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Choose a server to get started", color = Muted, fontSize = 13.sp)

                Spacer(Modifier.height(30.dp))
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(230.dp)) {
                    Box(
                        Modifier.size(220.dp).background(Purple.copy(alpha = .06f), CircleShape)
                            .border(1.dp, Purple.copy(alpha = .16f), CircleShape)
                    )
                    Box(
                        Modifier.size(184.dp).shadow(24.dp, CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF6D45D8), Color(0xFF34206F), Color(0xFF1A183D))), CircleShape)
                            .border(2.dp, Purple.copy(alpha = .8f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("CONNECT", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                    }
                }
                Spacer(Modifier.height(15.dp))
                Text("VPN server setup required", color = Color(0xFFFFC875), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text("Connect will be enabled after a real VPN server is configured.", color = Muted, fontSize = 11.sp)

                Spacer(Modifier.height(32.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SERVER LOCATION", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Text("FREE SERVERS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth()
                        .background(Surface.copy(alpha = .95f), RoundedCornerShape(18.dp))
                        .border(1.dp, Color(0xFF29314C), RoundedCornerShape(18.dp))
                        .clickable { showServers = true }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(flagFor(selectedServer), fontSize = 27.sp)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(selectedServer, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Server configuration not added", color = Muted, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Choose server", tint = Muted)
                }

                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard("DOWNLOAD", "—", "Mbps", Modifier.weight(1f))
                    MetricCard("UPLOAD", "—", "Mbps", Modifier.weight(1f))
                    MetricCard("PING", "—", "ms", Modifier.weight(1f))
                }
                Spacer(Modifier.weight(1f))
                Text("Your privacy matters. Use trusted VPN servers only.", color = Muted, fontSize = 10.sp)
                Spacer(Modifier.height(12.dp))
            }

            if (showServers) {
                AlertDialog(
                    onDismissRequest = { showServers = false },
                    containerColor = Surface,
                    title = { Text("Choose location", color = Color.White) },
                    text = {
                        Column {
                            listOf("India", "Singapore", "United States", "Germany", "Japan").forEach { server ->
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        selectedServer = server
                                        showServers = false
                                    }.padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(flagFor(server), fontSize = 23.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Text(server, color = Color.White, modifier = Modifier.weight(1f))
                                    if (selectedServer == server) Icon(Icons.Default.Check, contentDescription = null, tint = Purple)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showServers = false }) { Text("CLOSE", color = Purple) }
                    }
                )
            }

            if (showInfo) {
                AlertDialog(
                    onDismissRequest = { showInfo = false },
                    containerColor = Surface,
                    title = { Text("About Prime VPN") },
                    text = {
                        Text(
                            "This is the first UI build. Server locations are selectable previews only. A real encrypted VPN tunnel needs a provisioned server and its WireGuard configuration. No traffic is routed by this screen yet.",
                            color = Muted
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = { showInfo = false }) { Text("GOT IT", color = Purple) }
                    }
                )
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Surface, RoundedCornerShape(15.dp))
            .border(1.dp, Color(0xFF29314C), RoundedCornerShape(15.dp))
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(3.dp))
            Text(unit, color = Muted, fontSize = 9.sp)
        }
    }
}

private fun flagFor(server: String): String = when (server) {
    "India" -> "🇮🇳"
    "Singapore" -> "🇸🇬"
    "United States" -> "🇺🇸"
    "Germany" -> "🇩🇪"
    "Japan" -> "🇯🇵"
    else -> "🌐"
}
