# Prime VPN — Android UI Foundation (v0.1.0)

This project contains the first Android app foundation and the dark navy/purple Prime VPN interface.

## Included
- Jetpack Compose Android app
- Prime VPN branding and home screen
- Server-location selector (India, Singapore, US, Germany, Japan)
- Connection status and speed metric placeholders
- GitHub Actions workflow to build a debug APK

## Important: VPN is not connected yet
The server list is currently a UI selector only. This build does not create a VPN tunnel and does not route device traffic. A real VPN requires:
1. A VPN gateway/server that you are authorized to use.
2. Server-side WireGuard setup and securely generated client configuration.
3. Android WireGuard tunnel integration and Android VPN permission flow.
Do not enter random configuration files or use unknown public VPN servers.

## Build
Open this repository in Android Studio and build `app` with JDK 17 and Android SDK 35, or push to GitHub and run the `Build Prime VPN APK` workflow from Actions.
