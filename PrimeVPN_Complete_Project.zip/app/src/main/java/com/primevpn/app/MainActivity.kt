package com.primevpn.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF080B18)
private val Panel = Color(0xFF151B30)
private val Accent = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF39D7E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeVpnApp() }
    }
}

@Composable
fun PrimeVpnApp() {
    var splash by remember { mutableStateOf(true) }
    var connected by remember { mutableStateOf(false) }
    var connecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("India · Mumbai") }

    LaunchedEffect(Unit) {
        delay(1800)
        splash = false
    }
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(2400)
            connecting = false
            connected = !connected
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        if (splash) SplashScreen() else Dashboard(
            connected, connecting, selected,
            onToggle = {
                if (!connecting) {
                    if (connected) connected = false else connecting = true
                }
            },
            onServer = { selected = it }
        )
    }
}

@Composable
fun SplashScreen() {
    val infinite = rememberInfiniteTransition(label = "splash")
    val pulse by infinite.animateFloat(
        initialValue = 0.88f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF17113A), Bg, Color(0xFF090D1D)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(104.dp).scale(pulse).background(
                    Brush.linearGradient(listOf(Accent, Cyan)), CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Shield, null, tint = Color.White, modifier = Modifier.size(56.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text("PRIME VPN", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Spacer(Modifier.height(8.dp))
            Text("PRIVATE • FAST • SECURE", color = Color(0xFF9CA7C5), fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(28.dp))
            CircularProgressIndicator(color = Cyan, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
fun Dashboard(
    connected: Boolean,
    connecting: Boolean,
    selected: String,
    onToggle: () -> Unit,
    onServer: (String) -> Unit
) {
    val pulse = rememberInfiniteTransition(label = "button")
    val scale by pulse.animateFloat(
        1f, if (connecting) 1.06f else 1f,
        infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "scale"
    )
    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF10152B), Bg))
        ).padding(horizontal = 22.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Shield, null, tint = Cyan, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("PRIME VPN", fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, fontSize = 19.sp)
                Text("YOUR DIGITAL SPACE", color = Color(0xFF8994B3), fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.MoreVert, null, tint = Color.LightGray)
        }
        Spacer(Modifier.height(34.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Public, null, tint = Cyan)
                    Spacer(Modifier.width(8.dp))
                    Text("CURRENT LOCATION", color = Color(0xFF9BA6C4), fontSize = 11.sp, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text(selected, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Recommended server", color = Color(0xFF8792B0), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, null, tint = Cyan, modifier = Modifier.size(17.dp))
                    Text("  Smart route", color = Cyan, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {
                        val next = when (selected) {
                            "India · Mumbai" -> "Singapore · SG"
                            "Singapore · SG" -> "USA · New York"
                            "USA · New York" -> "Germany · Frankfurt"
                            else -> "India · Mumbai"
                        }
                        onServer(next)
                    }) { Text("CHANGE", color = Accent, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Spacer(Modifier.height(38.dp))
        Box(
            Modifier.size(206.dp).scale(scale).background(
                Brush.radialGradient(listOf(Color(0x5539D7E8), Color(0x228B5CF6), Color.Transparent)),
                CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(156.dp).background(
                    Brush.linearGradient(
                        if (connected) listOf(Color(0xFF0D9C9A), Color(0xFF176C9C))
                        else listOf(Color(0xFF6D45C7), Color(0xFF263B78))
                    ), CircleShape
                ).clickable { onToggle() },
                contentAlignment = Alignment.Center
            ) {
                if (connecting) CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                else Icon(
                    if (connected) Icons.Default.Check else Icons.Default.PowerSettingsNew,
                    null, tint = Color.White, modifier = Modifier.size(58.dp)
                )
            }
        }
        Spacer(Modifier.height(22.dp))
        Text(
            when { connecting -> "CONNECTING..."; connected -> "CONNECTED"; else -> "NOT CONNECTED" },
            fontSize = 20.sp, fontWeight = FontWeight.Bold,
            color = if (connected) Cyan else Color.White, letterSpacing = 2.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            when { connecting -> "Establishing visual connection"; connected -> "Visual session is active"; else -> "Tap the power button to start" },
            color = Color(0xFF8994B3), fontSize = 12.sp
        )
        Spacer(Modifier.height(30.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoTile("SESSION", if (connected) "00:24" else "--:--", Modifier.weight(1f))
            InfoTile("LATENCY", if (connected) "24 ms" else "--", Modifier.weight(1f))
            InfoTile("STATUS", if (connected) "ACTIVE" else "IDLE", Modifier.weight(1f))
        }
        Spacer(Modifier.weight(1f))
        Text(
            "Visual connection animation only. No VPN tunnel is created and your internet traffic is not protected.",
            color = Color(0xFF7F8AA8), fontSize = 10.sp, lineHeight = 15.sp
        )
    }
}

@Composable
fun InfoTile(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color(0xFF8994B3), fontSize = 9.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(7.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}
