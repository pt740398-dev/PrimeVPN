package com.primevpn.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay

private val Bg = Color(0xFF080A18)
private val Panel = Color(0xFF14172B)
private val Purple = Color(0xFF9B6BFF)
private val Cyan = Color(0xFF42D9E8)
private val Muted = Color(0xFF9298B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeVpnApp() }
    }
}

@Composable
fun PrimeVpnApp() {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(2300); splash = false }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple, secondary = Cyan
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            AnimatedContent(targetState = splash, label = "screen") { loading ->
                if (loading) SplashScreen() else HomeScreen()
            }
        }
    }
}

@Composable
fun SplashScreen() {
    val infinite = rememberInfiniteTransition(label = "splash")
    val rotation by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "rot")
    val pulse by infinite.animateFloat(0.88f, 1.08f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF17102F), Bg, Color(0xFF090D20)))
    ), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(132.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxSize().rotate(rotation).border(2.dp, Brush.sweepGradient(listOf(Purple, Cyan, Color.Transparent, Purple)), CircleShape))
                Box(Modifier.size(96.dp).scale(pulse).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Color(0xFF4730A0)))), contentAlignment = Alignment.Center) {
                    Text("P", fontSize = 58.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("PRIME VPN", fontSize = 29.sp, letterSpacing = 4.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text("YOUR CONNECTION, YOUR STYLE", fontSize = 10.sp, letterSpacing = 2.sp, color = Muted)
            Spacer(Modifier.height(36.dp))
            LinearProgressIndicator(Modifier.width(150.dp).height(3.dp).clip(CircleShape), color = Cyan, trackColor = Panel)
        }
    }
}

@Composable
fun HomeScreen() {
    var connected by remember { mutableStateOf(false) }
    var connecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Singapore") }
    var elapsed by remember { mutableIntStateOf(0) }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(0.25f, 0.8f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "glow")
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(2400)
            connecting = false
            connected = true
        }
    }
    LaunchedEffect(connected) {
        while (connected) { delay(1000); elapsed++ }
        elapsed = 0
    }
    val mins = elapsed / 60
    val secs = elapsed % 60

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .background(Brush.verticalGradient(listOf(Color(0xFF11142B), Bg, Bg)))
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF4730A0)))), contentAlignment = Alignment.Center) {
                Text("P", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Color.White)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("PRIME VPN", fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = Color.White)
                Text("PRIVATE • FAST • SIMPLE", fontSize = 9.sp, color = Muted, letterSpacing = 1.2.sp)
            }
            Icon(Icons.Default.NotificationsNone, null, tint = Color.White, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(27.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dashboard", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
            Surface(color = Color(0xFF1D2940), shape = CircleShape) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Cyan))
                    Spacer(Modifier.width(6.dp))
                    Text("READY", fontSize = 9.sp, color = Cyan, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(
            Brush.linearGradient(listOf(Color(0xFF25204A), Color(0xFF151A35), Color(0xFF10182A)))
        ).padding(20.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (connecting) "ESTABLISHING CONNECTION" else if (connected) "SESSION ACTIVE" else "PROTECTION STATUS", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(17.dp))
                Box(Modifier.size(205.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxSize().padding(5.dp).border(2.dp, Color(0xFF33365A), CircleShape))
                    Box(Modifier.fillMaxSize().padding(5.dp).rotate(if (connecting) (System.currentTimeMillis() % 3600 / 10).toFloat() else 0f)
                        .border(3.dp, Brush.sweepGradient(listOf(Cyan, Purple, Color.Transparent, Cyan)), CircleShape))
                    Box(Modifier.size(165.dp).shadow(22.dp, CircleShape, ambientColor = Purple.copy(alpha = glow), spotColor = Purple.copy(alpha = glow))
                        .clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF6C48C9), Color(0xFF30235E)))), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(if (connected) Icons.Default.Check else Icons.Default.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(39.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(if (connecting) "WAIT" else if (connected) "ACTIVE" else "CONNECT", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, letterSpacing = 1.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(if (connecting) "Preparing visual connection…" else if (connected) "Session animation is running" else "Tap to start the connection animation", color = Color.White, fontSize = 12.sp)
                Spacer(Modifier.height(17.dp))
                Button(
                    onClick = { if (connected) connected = false else if (!connecting) connecting = true },
                    enabled = !connecting,
                    colors = ButtonDefaults.buttonColors(containerColor = if (connected) Color(0xFF343A55) else Purple),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text(if (connecting) "CONNECTING..." else if (connected) "DISCONNECT" else "CONNECT NOW", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(10.dp))
                Text("Visual connection animation only — no VPN tunnel is created.", fontSize = 9.sp, color = Muted, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(19.dp))
        Text("SELECT LOCATION", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        val servers = listOf("🇮🇳" to "India", "🇸🇬" to "Singapore", "🇺🇸" to "United States", "🇩🇪" to "Germany")
        servers.forEach { item ->
            val active = selected == item.second
            Row(
                Modifier.fillMaxWidth().padding(bottom = 9.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (active) Color(0xFF282044) else Panel)
                    .border(if (active) 1.dp else 0.dp, if (active) Purple else Color.Transparent, RoundedCornerShape(16.dp))
                    .clickable { selected = item.second }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(item.first, fontSize = 24.sp)
                Spacer(Modifier.width(12.dp))
                Text(item.second, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (active) Icon(Icons.Default.CheckCircle, null, tint = Cyan)
                else Text("SELECT", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("SESSION TIMER", if (connected) "%02d:%02d".format(mins, secs) else "00:00", Modifier.weight(1f))
            MetricCard("SELECTED SERVER", selected, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("PRIME • SIMPLE • CLEAN", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(Panel).padding(14.dp)) {
        Text(title, fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        Text(value, fontSize = 17.sp, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
